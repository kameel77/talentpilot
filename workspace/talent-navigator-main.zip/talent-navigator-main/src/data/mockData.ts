import { TeamMember, Team, Organization, DailyTip, DomainDistribution } from '@/types/talent';

export const mockTeamMembers: TeamMember[] = [
  {
    id: '1',
    firstName: 'Anna',
    lastName: 'Kowalska',
    email: 'anna.kowalska@firma.pl',
    role: 'manager',
    talents: [
      { talentId: 'achiever', rank: 1 },
      { talentId: 'strategic', rank: 2 },
      { talentId: 'learner', rank: 3 },
      { talentId: 'activator', rank: 4 },
      { talentId: 'communication', rank: 5 },
    ],
    topTalents: ['achiever', 'strategic', 'learner', 'activator', 'communication'],
    strengths: [
      'Doskonała w realizacji celów i pilnowaniu terminów',
      'Naturalna liderka z wizją strategiczną',
      'Szybko przyswaja nowe umiejętności',
    ],
    triggers: [
      'Brak jasnych celów lub kierunku',
      'Zbyt wolne tempo pracy zespołu',
      'Ignorowanie jej pomysłów',
    ],
    blockers: [
      'Zbyt dużo spotkań bez konkretnych rezultatów',
      'Mikrozarządzanie',
      'Brak autonomii w podejmowaniu decyzji',
    ],
    feedbackGuidance: 'Anna najlepiej reaguje na konkretny, zorientowany na cele feedback. Doceniaj jej osiągnięcia i dawaj jej przestrzeń do samodzielnego działania.',
    createdAt: new Date('2024-01-15'),
  },
  {
    id: '2',
    firstName: 'Piotr',
    lastName: 'Nowak',
    email: 'piotr.nowak@firma.pl',
    role: 'user',
    talents: [
      { talentId: 'empathy', rank: 1 },
      { talentId: 'developer', rank: 2 },
      { talentId: 'harmony', rank: 3 },
      { talentId: 'relator', rank: 4 },
      { talentId: 'analytical', rank: 5 },
    ],
    topTalents: ['empathy', 'developer', 'harmony', 'relator', 'analytical'],
    strengths: [
      'Wyczuwa nastroje zespołu i reaguje na potrzeby',
      'Świetny mentor dla młodszych kolegów',
      'Buduje głębokie, trwałe relacje',
    ],
    triggers: [
      'Konflikty w zespole',
      'Brak uznania dla jego wsparcia',
      'Powierzchowne relacje',
    ],
    blockers: [
      'Agresywna komunikacja',
      'Presja na szybkie decyzje bez refleksji',
      'Ignorowanie potrzeb emocjonalnych zespołu',
    ],
    feedbackGuidance: 'Piotr potrzebuje empatycznego podejścia. Zacznij od docenienia jego wkładu w zespół, potem przejdź do konstruktywnych sugestii.',
    createdAt: new Date('2024-02-20'),
  },
  {
    id: '3',
    firstName: 'Magdalena',
    lastName: 'Wiśniewska',
    email: 'magdalena.wisniewska@firma.pl',
    role: 'user',
    talents: [
      { talentId: 'ideation', rank: 1 },
      { talentId: 'futuristic', rank: 2 },
      { talentId: 'woo', rank: 3 },
      { talentId: 'communication', rank: 4 },
      { talentId: 'positivity', rank: 5 },
    ],
    topTalents: ['ideation', 'futuristic', 'woo', 'communication', 'positivity'],
    strengths: [
      'Generuje innowacyjne pomysły i rozwiązania',
      'Inspiruje zespół wizją przyszłości',
      'Łatwo nawiązuje kontakty i buduje sieć',
    ],
    triggers: [
      'Rutynowe, powtarzalne zadania',
      'Brak możliwości wyrażenia kreatywności',
      'Negatywna atmosfera',
    ],
    blockers: [
      'Zbyt sztywne procedury',
      'Krytykowanie pomysłów bez konstruktywnego feedbacku',
      'Izolacja od zespołu',
    ],
    feedbackGuidance: 'Magdalena potrzebuje entuzjazmu i otwartości na jej pomysły. Nawet konstruktywną krytykę podawaj w pozytywnym kontekście.',
    createdAt: new Date('2024-03-10'),
  },
  {
    id: '4',
    firstName: 'Tomasz',
    lastName: 'Zieliński',
    email: 'tomasz.zielinski@firma.pl',
    role: 'user',
    talents: [
      { talentId: 'analytical', rank: 1 },
      { talentId: 'deliberative', rank: 2 },
      { talentId: 'discipline', rank: 3 },
      { talentId: 'focus', rank: 4 },
      { talentId: 'responsibility', rank: 5 },
    ],
    topTalents: ['analytical', 'deliberative', 'discipline', 'focus', 'responsibility'],
    strengths: [
      'Dokładna analiza danych i faktów',
      'Przemyślane, odpowiedzialne decyzje',
      'Doskonała organizacja i planowanie',
    ],
    triggers: [
      'Chaotyczne środowisko pracy',
      'Decyzje podejmowane bez analizy',
      'Brak jasnej struktury',
    ],
    blockers: [
      'Presja czasowa bez możliwości refleksji',
      'Ignorowanie jego analiz',
      'Częste zmiany planów',
    ],
    feedbackGuidance: 'Tomasz potrzebuje faktów i danych. Przygotuj konkrety i daj mu czas na przemyślenie informacji przed dyskusją.',
    createdAt: new Date('2024-01-25'),
  },
  {
    id: '5',
    firstName: 'Karolina',
    lastName: 'Dąbrowska',
    email: 'karolina.dabrowska@firma.pl',
    role: 'user',
    talents: [
      { talentId: 'command', rank: 1 },
      { talentId: 'competition', rank: 2 },
      { talentId: 'activator', rank: 3 },
      { talentId: 'self-assurance', rank: 4 },
      { talentId: 'significance', rank: 5 },
    ],
    topTalents: ['command', 'competition', 'activator', 'self-assurance', 'significance'],
    strengths: [
      'Naturalna liderka, która przejmuje inicjatywę',
      'Wysoka motywacja do osiągania wyników',
      'Szybkie działanie i decyzyjność',
    ],
    triggers: [
      'Brak wyzwań',
      'Bycie ignorowaną w dyskusjach',
      'Wolne tempo podejmowania decyzji',
    ],
    blockers: [
      'Ograniczanie jej autonomii',
      'Brak uznania dla osiągnięć',
      'Praca bez jasnych celów i wyników',
    ],
    feedbackGuidance: 'Karolina szanuje bezpośredniość. Bądź konkretny, stawiaj wyzwania i doceniaj jej osiągnięcia publicznie.',
    createdAt: new Date('2024-04-05'),
  },
];

export const mockTeam: Team = {
  id: 'team-1',
  name: 'Zespół Produktowy',
  description: 'Zespół odpowiedzialny za rozwój głównego produktu',
  members: mockTeamMembers,
  managerId: '1',
  createdAt: new Date('2024-01-01'),
};

export const mockOrganization: Organization = {
  id: 'org-1',
  name: 'TechCorp Polska',
  teams: [mockTeam],
  createdAt: new Date('2024-01-01'),
};

export const mockDailyTips: DailyTip[] = [
  {
    id: 'tip-1',
    title: 'Wskazówka na spotkanie z Anną',
    content: 'Anna ma silny talent Osiągania. Przed spotkaniem przygotuj konkretne cele i rezultaty, które chcesz osiągnąć. Doceni jasną strukturę i możliwość od razu przejścia do działania.',
    category: 'communication',
    targetDomain: 'executing',
    createdAt: new Date(),
    isHelpful: null,
  },
  {
    id: 'tip-2',
    title: 'Budowanie mostu z Piotrem',
    content: 'Piotr z talentem Empatii doskonale wyczuwa nastroje. Zanim przejdziesz do meritum, zapytaj jak się czuje i daj mu chwilę na wyrażenie myśli. To zbuduje zaufanie i otworzy go na współpracę.',
    category: 'collaboration',
    targetDomain: 'relationship',
    createdAt: new Date(),
    isHelpful: null,
  },
  {
    id: 'tip-3',
    title: 'Wykorzystaj kreatywność Magdaleny',
    content: 'Magdalena z talentem Pomysłowości potrzebuje przestrzeni na burze mózgów. Zamiast od razu oceniać pomysły, pozwól jej najpierw wygenerować wiele opcji. Najlepsze rozwiązania często pojawiają się po chwili eksploracji.',
    category: 'development',
    targetDomain: 'strategic',
    createdAt: new Date(),
    isHelpful: null,
  },
  {
    id: 'tip-4',
    title: 'Współpraca z Tomaszem',
    content: 'Tomasz z talentem Analityka potrzebuje danych i czasu. Przed spotkaniem wyślij mu materiały do przeglądu. Doceni możliwość przygotowania się i przyjdzie z przemyślanymi wnioskami.',
    category: 'leadership',
    targetDomain: 'executing',
    createdAt: new Date(),
    isHelpful: null,
  },
];

export const mockDomainDistribution: DomainDistribution = {
  executing: 35,
  influencing: 25,
  relationship: 22,
  strategic: 18,
};

// KPI data in Polish
export const mockKPIs = {
  teamSize: 5,
  talentsImported: 25,
  comparisonsMade: 12,
  tipsViewed: 48,
  avgEngagement: 87,
};

// Gallup Talent Domains
export type GallupDomain = 'executing' | 'influencing' | 'relationship' | 'strategic';

export interface GallupTalent {
  id: string;
  name: string;
  namePl: string;
  domain: GallupDomain;
  description: string;
  descriptionPl: string;
}

export interface UserTalent {
  talentId: string;
  rank: number; // 1-34 ranking
}

export interface TeamMember {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  avatar?: string;
  role: 'admin' | 'manager' | 'user';
  talents: UserTalent[];
  topTalents: string[]; // Top 5-10 talent IDs
  strengths: string[];
  triggers: string[];
  blockers: string[];
  feedbackGuidance: string;
  createdAt: Date;
}

export interface Team {
  id: string;
  name: string;
  description?: string;
  members: TeamMember[];
  managerId: string;
  createdAt: Date;
}

export interface Organization {
  id: string;
  name: string;
  logo?: string;
  teams: Team[];
  createdAt: Date;
}

export interface DailyTip {
  id: string;
  title: string;
  content: string;
  category: 'communication' | 'collaboration' | 'development' | 'leadership';
  targetDomain?: GallupDomain;
  createdAt: Date;
  isHelpful?: boolean | null;
}

export interface ComparisonResult {
  personA: TeamMember;
  personB: TeamMember;
  bridges: string[]; // Shared strengths / complementary talents
  barriers: string[]; // Potential friction points
  tips: string[];
}

// Domain distribution for KPIs
export interface DomainDistribution {
  executing: number;
  influencing: number;
  relationship: number;
  strategic: number;
}

import { useState } from 'react';
import { AppLayout } from '@/components/AppLayout';
import { TeamMemberCard } from '@/components/TeamMemberCard';
import { DomainBadge } from '@/components/DomainBadge';
import { mockTeamMembers } from '@/data/mockData';
import { getTalentById, DOMAIN_LABELS } from '@/data/gallupTalents';
import { TeamMember, GallupDomain } from '@/types/talent';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Search,
  ArrowLeft,
  ThumbsUp,
  AlertCircle,
  XCircle,
  MessageSquare,
  Star,
  X,
} from 'lucide-react';
import { cn } from '@/lib/utils';

export default function TeamPage() {
  const [selectedMember, setSelectedMember] = useState<TeamMember | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterDomain, setFilterDomain] = useState<GallupDomain | null>(null);

  const filteredMembers = mockTeamMembers.filter((member) => {
    const matchesSearch =
      `${member.firstName} ${member.lastName}`.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (!filterDomain) return matchesSearch;
    
    const memberDomains = member.topTalents.map((t) => getTalentById(t)?.domain);
    return matchesSearch && memberDomains.includes(filterDomain);
  });

  const domains: GallupDomain[] = ['executing', 'influencing', 'relationship', 'strategic'];

  if (selectedMember) {
    return (
      <AppLayout>
        <EmployeeProfile member={selectedMember} onBack={() => setSelectedMember(null)} />
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-headline">Zespół</h1>
          <p className="text-body">Przeglądaj profile talentowe członków zespołu</p>
        </div>

        {/* Filters */}
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Szukaj po imieniu lub nazwisku..."
              className="pl-11"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="flex flex-wrap gap-2">
            <Button
              variant={filterDomain === null ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilterDomain(null)}
            >
              Wszyscy
            </Button>
            {domains.map((domain) => (
              <Button
                key={domain}
                variant={filterDomain === domain ? 'default' : 'outline'}
                size="sm"
                onClick={() => setFilterDomain(domain)}
                className={cn(
                  filterDomain === domain && domain === 'executing' && 'bg-domain-executing hover:bg-domain-executing/90',
                  filterDomain === domain && domain === 'influencing' && 'bg-domain-influencing hover:bg-domain-influencing/90',
                  filterDomain === domain && domain === 'relationship' && 'bg-domain-relationship hover:bg-domain-relationship/90',
                  filterDomain === domain && domain === 'strategic' && 'bg-domain-strategic hover:bg-domain-strategic/90'
                )}
              >
                {DOMAIN_LABELS[domain].pl}
              </Button>
            ))}
          </div>
        </div>

        {/* Team grid */}
        {filteredMembers.length > 0 ? (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {filteredMembers.map((member) => (
              <TeamMemberCard
                key={member.id}
                member={member}
                onClick={() => setSelectedMember(member)}
              />
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="mb-4 rounded-full bg-muted p-4">
              <Search className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-title mb-2">Brak wyników</h3>
            <p className="text-body max-w-sm">
              Nie znaleziono członków zespołu pasujących do kryteriów wyszukiwania.
            </p>
          </div>
        )}
      </div>
    </AppLayout>
  );
}

// Employee Profile Component
interface EmployeeProfileProps {
  member: TeamMember;
  onBack: () => void;
}

function EmployeeProfile({ member, onBack }: EmployeeProfileProps) {
  const topTalentsWithDetails = member.topTalents.map((id) => getTalentById(id)).filter(Boolean);

  // Group talents by domain
  const talentsByDomain = topTalentsWithDetails.reduce((acc, talent) => {
    if (!talent) return acc;
    if (!acc[talent.domain]) acc[talent.domain] = [];
    acc[talent.domain].push(talent);
    return acc;
  }, {} as Record<GallupDomain, typeof topTalentsWithDetails>);

  return (
    <div className="space-y-6">
      {/* Back button */}
      <Button variant="ghost" onClick={onBack} className="gap-2">
        <ArrowLeft className="h-4 w-4" />
        Powrót do zespołu
      </Button>

      {/* Profile header */}
      <div className="rounded-2xl border bg-card p-6 shadow-soft">
        <div className="flex flex-col gap-6 md:flex-row md:items-center">
          <div className="relative">
            <div className="flex h-24 w-24 items-center justify-center rounded-2xl bg-gradient-primary text-primary-foreground text-3xl font-bold">
              {member.firstName[0]}{member.lastName[0]}
            </div>
            {member.role === 'manager' && (
              <div className="absolute -bottom-2 -right-2 flex h-8 w-8 items-center justify-center rounded-full bg-warning text-warning-foreground shadow-lg">
                <Star className="h-4 w-4" />
              </div>
            )}
          </div>
          <div className="flex-1">
            <h1 className="text-headline">
              {member.firstName} {member.lastName}
            </h1>
            <p className="text-body mb-3">
              {member.role === 'manager' ? 'Menedżer zespołu' : 'Członek zespołu'} • {member.email}
            </p>
            <div className="flex flex-wrap gap-2">
              {topTalentsWithDetails.slice(0, 5).map((talent) => (
                talent && <DomainBadge key={talent.id} domain={talent.domain} size="sm" />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Main content grid */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Talents by domain */}
        <div className="rounded-2xl border bg-card p-6 shadow-soft">
          <h2 className="text-title mb-4 flex items-center gap-2">
            <Star className="h-5 w-5 text-warning" />
            Top talenty
          </h2>
          <div className="space-y-4">
            {(Object.entries(talentsByDomain) as [GallupDomain, typeof topTalentsWithDetails][]).map(
              ([domain, talents]) => (
                <div key={domain} className="space-y-2">
                  <p className="text-label">{DOMAIN_LABELS[domain].pl}</p>
                  <div className="flex flex-wrap gap-2">
                    {talents.map((talent) => (
                      talent && (
                        <span
                          key={talent.id}
                          className={cn(
                            'rounded-lg px-3 py-1.5 text-sm font-medium',
                            domain === 'executing' && 'bg-domain-executing-light text-domain-executing',
                            domain === 'influencing' && 'bg-domain-influencing-light text-domain-influencing',
                            domain === 'relationship' && 'bg-domain-relationship-light text-domain-relationship',
                            domain === 'strategic' && 'bg-domain-strategic-light text-domain-strategic'
                          )}
                        >
                          {talent.namePl}
                        </span>
                      )
                    ))}
                  </div>
                </div>
              )
            )}
          </div>
        </div>

        {/* User Manual sections */}
        <div className="space-y-4">
          {/* Strengths */}
          <div className="rounded-2xl border bg-gradient-to-br from-success/5 to-transparent p-5 shadow-soft">
            <h3 className="text-title mb-3 flex items-center gap-2">
              <ThumbsUp className="h-5 w-5 text-success" />
              Mocne strony
            </h3>
            <ul className="space-y-2">
              {member.strengths.map((strength, i) => (
                <li key={i} className="flex items-start gap-2 text-sm">
                  <span className="mt-1.5 h-1.5 w-1.5 rounded-full bg-success shrink-0" />
                  {strength}
                </li>
              ))}
            </ul>
          </div>

          {/* Triggers */}
          <div className="rounded-2xl border bg-gradient-to-br from-warning/5 to-transparent p-5 shadow-soft">
            <h3 className="text-title mb-3 flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-warning" />
              Wyzwalacze
            </h3>
            <ul className="space-y-2">
              {member.triggers.map((trigger, i) => (
                <li key={i} className="flex items-start gap-2 text-sm">
                  <span className="mt-1.5 h-1.5 w-1.5 rounded-full bg-warning shrink-0" />
                  {trigger}
                </li>
              ))}
            </ul>
          </div>

          {/* Blockers */}
          <div className="rounded-2xl border bg-gradient-to-br from-destructive/5 to-transparent p-5 shadow-soft">
            <h3 className="text-title mb-3 flex items-center gap-2">
              <XCircle className="h-5 w-5 text-destructive" />
              Blokady
            </h3>
            <ul className="space-y-2">
              {member.blockers.map((blocker, i) => (
                <li key={i} className="flex items-start gap-2 text-sm">
                  <span className="mt-1.5 h-1.5 w-1.5 rounded-full bg-destructive shrink-0" />
                  {blocker}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Feedback guidance */}
      <div className="rounded-2xl border bg-gradient-to-br from-primary/5 to-transparent p-6 shadow-soft">
        <h3 className="text-title mb-3 flex items-center gap-2">
          <MessageSquare className="h-5 w-5 text-primary" />
          Jak dawać feedback
        </h3>
        <p className="text-body leading-relaxed">{member.feedbackGuidance}</p>
      </div>
    </div>
  );
}

import { AppLayout } from '@/components/AppLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import {
  Building2,
  Users,
  Bell,
  Shield,
  Palette,
  Globe,
  ChevronRight,
  Save,
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface SettingsSectionProps {
  icon: React.ElementType;
  title: string;
  description: string;
  children: React.ReactNode;
}

function SettingsSection({ icon: Icon, title, description, children }: SettingsSectionProps) {
  return (
    <div className="rounded-2xl border bg-card p-6 shadow-soft">
      <div className="flex items-start gap-4 mb-6">
        <div className="rounded-xl bg-primary/10 p-3 text-primary">
          <Icon className="h-6 w-6" />
        </div>
        <div>
          <h3 className="text-title">{title}</h3>
          <p className="text-sm text-muted-foreground">{description}</p>
        </div>
      </div>
      {children}
    </div>
  );
}

export default function SettingsPage() {
  return (
    <AppLayout>
      <div className="mx-auto max-w-3xl space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-headline">Ustawienia</h1>
          <p className="text-body">Zarządzaj ustawieniami konta i organizacji</p>
        </div>

        {/* Organization */}
        <SettingsSection
          icon={Building2}
          title="Organizacja"
          description="Informacje o Twojej organizacji"
        >
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="org-name">Nazwa organizacji</Label>
              <Input id="org-name" defaultValue="TechCorp Polska" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="org-domain">Domena email</Label>
              <Input id="org-domain" defaultValue="techcorp.pl" />
            </div>
          </div>
        </SettingsSection>

        {/* Team management */}
        <SettingsSection
          icon={Users}
          title="Zarządzanie zespołem"
          description="Role i uprawnienia w zespole"
        >
          <div className="space-y-4">
            <div className="flex items-center justify-between py-3 border-b">
              <div>
                <p className="font-medium">Administratorzy</p>
                <p className="text-sm text-muted-foreground">Pełny dostęp do wszystkich funkcji</p>
              </div>
              <span className="text-sm text-muted-foreground">1 osoba</span>
            </div>
            <div className="flex items-center justify-between py-3 border-b">
              <div>
                <p className="font-medium">Menedżerowie</p>
                <p className="text-sm text-muted-foreground">Zarządzanie zespołem i raportami</p>
              </div>
              <span className="text-sm text-muted-foreground">2 osoby</span>
            </div>
            <div className="flex items-center justify-between py-3">
              <div>
                <p className="font-medium">Użytkownicy</p>
                <p className="text-sm text-muted-foreground">Podstawowy dostęp do profili</p>
              </div>
              <span className="text-sm text-muted-foreground">3 osoby</span>
            </div>
            <Button variant="outline" className="w-full">
              Zarządzaj użytkownikami
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </SettingsSection>

        {/* Notifications */}
        <SettingsSection
          icon={Bell}
          title="Powiadomienia"
          description="Ustawienia powiadomień i alertów"
        >
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Dzienne wskazówki</p>
                <p className="text-sm text-muted-foreground">Otrzymuj codzienną wskazówkę rano</p>
              </div>
              <Switch defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Przypomnienia o spotkaniach</p>
                <p className="text-sm text-muted-foreground">Briefing przed spotkaniami 1:1</p>
              </div>
              <Switch defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Tygodniowe podsumowanie</p>
                <p className="text-sm text-muted-foreground">Raport aktywności zespołu</p>
              </div>
              <Switch />
            </div>
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Powiadomienia email</p>
                <p className="text-sm text-muted-foreground">Otrzymuj alerty na email</p>
              </div>
              <Switch defaultChecked />
            </div>
          </div>
        </SettingsSection>

        {/* Privacy */}
        <SettingsSection
          icon={Shield}
          title="Prywatność i bezpieczeństwo"
          description="Ustawienia prywatności danych"
        >
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Widoczność profilu</p>
                <p className="text-sm text-muted-foreground">Kto może widzieć Twój profil talentowy</p>
              </div>
              <Button variant="outline" size="sm">
                Tylko zespół
              </Button>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Uwierzytelnianie dwuskładnikowe</p>
                <p className="text-sm text-muted-foreground">Dodatkowa warstwa bezpieczeństwa</p>
              </div>
              <Switch />
            </div>
            <Button variant="outline" className="w-full">
              Eksportuj dane
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </SettingsSection>

        {/* Extensions - Post MVP */}
        <div className="space-y-4">
          <h2 className="text-title text-muted-foreground">Rozszerzenia (wkrótce)</h2>
          
          <div className="grid gap-4 md:grid-cols-2">
            <div className="rounded-2xl border border-dashed bg-muted/30 p-6 opacity-60">
              <div className="flex items-center gap-3 mb-3">
                <div className="rounded-lg bg-muted p-2">
                  <Globe className="h-5 w-5 text-muted-foreground" />
                </div>
                <span className="text-sm font-medium">Integracja z kalendarzem</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Automatyczne briefing przed spotkaniami
              </p>
            </div>
            
            <div className="rounded-2xl border border-dashed bg-muted/30 p-6 opacity-60">
              <div className="flex items-center gap-3 mb-3">
                <div className="rounded-lg bg-muted p-2">
                  <Palette className="h-5 w-5 text-muted-foreground" />
                </div>
                <span className="text-sm font-medium">Zdrowie organizacji</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Widok heatmapy dla całej firmy
              </p>
            </div>
          </div>
        </div>

        {/* Save button */}
        <div className="flex justify-end">
          <Button variant="hero" size="lg">
            <Save className="h-5 w-5" />
            Zapisz zmiany
          </Button>
        </div>
      </div>
    </AppLayout>
  );
}

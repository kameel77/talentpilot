import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Mail, Lock, ArrowRight, Eye, EyeOff } from 'lucide-react';

type AuthMode = 'login' | 'signup' | 'reset';

export default function AuthPage() {
  const [mode, setMode] = useState<AuthMode>('login');
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Navigate to dashboard on submit
    window.location.href = '/dashboard';
  };

  return (
    <div className="flex min-h-screen w-full">
      {/* Left - Form */}
      <div className="flex flex-1 flex-col justify-center px-6 py-12 lg:px-12">
        <div className="mx-auto w-full max-w-md">
          {/* Logo */}
          <div className="mb-8">
            <Link to="/" className="inline-flex items-center gap-2">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-primary text-primary-foreground font-bold text-lg">
                TP
              </div>
              <span className="font-display font-bold text-xl">TalentPilot</span>
            </Link>
          </div>

          {/* Header */}
          <div className="mb-8">
            <h1 className="text-headline mb-2">
              {mode === 'login' && 'Witaj ponownie'}
              {mode === 'signup' && 'Utwórz konto'}
              {mode === 'reset' && 'Zresetuj hasło'}
            </h1>
            <p className="text-body">
              {mode === 'login' && 'Zaloguj się, aby zarządzać talentami swojego zespołu'}
              {mode === 'signup' && 'Dołącz do TalentPilot i odkryj potencjał zespołu'}
              {mode === 'reset' && 'Podaj email, wyślemy link do zresetowania hasła'}
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="email"
                  type="email"
                  placeholder="jan.kowalski@firma.pl"
                  className="pl-11 h-12"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
            </div>

            {mode !== 'reset' && (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password">Hasło</Label>
                  {mode === 'login' && (
                    <button
                      type="button"
                      onClick={() => setMode('reset')}
                      className="text-sm text-primary hover:underline"
                    >
                      Zapomniałeś hasła?
                    </button>
                  )}
                </div>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="••••••••"
                    className="pl-11 pr-11 h-12"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                  </button>
                </div>
              </div>
            )}

            <Button type="submit" variant="hero" size="lg" className="w-full">
              {mode === 'login' && 'Zaloguj się'}
              {mode === 'signup' && 'Utwórz konto'}
              {mode === 'reset' && 'Wyślij link'}
              <ArrowRight className="h-5 w-5" />
            </Button>
          </form>

          {/* Mode switch */}
          <div className="mt-6 text-center text-sm">
            {mode === 'login' && (
              <p className="text-muted-foreground">
                Nie masz konta?{' '}
                <button
                  onClick={() => setMode('signup')}
                  className="font-medium text-primary hover:underline"
                >
                  Zarejestruj się
                </button>
              </p>
            )}
            {mode === 'signup' && (
              <p className="text-muted-foreground">
                Masz już konto?{' '}
                <button
                  onClick={() => setMode('login')}
                  className="font-medium text-primary hover:underline"
                >
                  Zaloguj się
                </button>
              </p>
            )}
            {mode === 'reset' && (
              <button
                onClick={() => setMode('login')}
                className="font-medium text-primary hover:underline"
              >
                ← Powrót do logowania
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Right - Hero */}
      <div className="hidden lg:flex lg:flex-1 bg-gradient-hero relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-domain-strategic/20 via-transparent to-transparent" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,_var(--tw-gradient-stops))] from-domain-relationship/20 via-transparent to-transparent" />
        
        <div className="relative z-10 flex flex-col justify-center p-12 text-white">
          <div className="max-w-lg">
            <h2 className="text-display mb-6">
              Odkryj potencjał <span className="text-domain-strategic">talentów</span> w Twoim zespole
            </h2>
            <p className="text-lg text-white/80 leading-relaxed mb-8">
              TalentPilot pomaga menedżerom zrozumieć unikalne talenty Gallupa każdego członka zespołu, 
              budować silniejsze relacje i maksymalizować efektywność współpracy.
            </p>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6">
              <div className="space-y-1">
                <p className="text-3xl font-bold font-display">34</p>
                <p className="text-sm text-white/60">Talenty Gallupa</p>
              </div>
              <div className="space-y-1">
                <p className="text-3xl font-bold font-display">4</p>
                <p className="text-sm text-white/60">Domeny</p>
              </div>
              <div className="space-y-1">
                <p className="text-3xl font-bold font-display">∞</p>
                <p className="text-sm text-white/60">Możliwości</p>
              </div>
            </div>
          </div>

          {/* Decorative elements */}
          <div className="absolute top-20 right-20 h-64 w-64 rounded-full border border-white/10" />
          <div className="absolute bottom-32 right-32 h-40 w-40 rounded-full border border-white/10" />
          <div className="absolute bottom-20 right-60 h-20 w-20 rounded-full bg-domain-influencing/30 blur-xl" />
          <div className="absolute top-40 right-40 h-32 w-32 rounded-full bg-domain-executing/20 blur-2xl" />
        </div>
      </div>
    </div>
  );
}

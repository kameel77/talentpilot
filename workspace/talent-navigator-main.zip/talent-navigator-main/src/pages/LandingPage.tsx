import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import {
  ArrowRight,
  Users,
  GitCompare,
  Lightbulb,
  BarChart3,
  Shield,
  Sparkles,
  Check,
} from 'lucide-react';

export default function LandingPage() {
  const features = [
    {
      icon: Users,
      title: 'Profile talentowe',
      description: 'Kompleksowe profile każdego członka zespołu z 34 talentami Gallupa',
    },
    {
      icon: GitCompare,
      title: 'Porównania 1:1',
      description: 'Odkryj mosty i bariery między dowolnymi dwoma osobami',
    },
    {
      icon: Lightbulb,
      title: 'Dzienne wskazówki',
      description: 'Spersonalizowane porady dostosowane do talentów Twojego zespołu',
    },
    {
      icon: BarChart3,
      title: 'Heatmapa kompetencji',
      description: 'Wizualizacja rozkładu domenowego w całym zespole',
    },
    {
      icon: Shield,
      title: 'Bezpieczne dane',
      description: 'Pełna kontrola nad prywatnością i dostępem do danych',
    },
    {
      icon: Sparkles,
      title: 'Asystent AI',
      description: 'Inteligentne sugestie oparte na wzorcach talentowych',
    },
  ];

  const domains = [
    { name: 'Realizacja', color: 'bg-domain-executing', count: 9 },
    { name: 'Wpływanie', color: 'bg-domain-influencing', count: 8 },
    { name: 'Budowanie relacji', color: 'bg-domain-relationship', count: 9 },
    { name: 'Myślenie strategiczne', color: 'bg-domain-strategic', count: 8 },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 border-b bg-background/80 backdrop-blur-xl">
        <div className="container flex h-16 items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-primary text-primary-foreground font-bold">
              TP
            </div>
            <span className="font-display font-bold text-xl">TalentPilot</span>
          </Link>
          <div className="flex items-center gap-4">
            <Link to="/auth">
              <Button variant="ghost">Zaloguj się</Button>
            </Link>
            <Link to="/auth">
              <Button variant="hero">
                Rozpocznij za darmo
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-hero" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-domain-strategic/30 via-transparent to-transparent" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,_var(--tw-gradient-stops))] from-domain-relationship/20 via-transparent to-transparent" />
        
        {/* Decorative circles */}
        <div className="absolute top-20 right-[10%] h-96 w-96 rounded-full border border-white/5" />
        <div className="absolute top-40 right-[15%] h-64 w-64 rounded-full border border-white/10" />
        <div className="absolute bottom-20 left-[5%] h-32 w-32 rounded-full bg-domain-influencing/10 blur-3xl" />
        
        <div className="container relative z-10 py-24 md:py-32 lg:py-40">
          <div className="mx-auto max-w-4xl text-center text-white">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-4 py-2 text-sm backdrop-blur">
              <Sparkles className="h-4 w-4" />
              <span>Zarządzanie talentami Gallupa</span>
            </div>
            
            <h1 className="text-display mb-6">
              Odkryj <span className="text-domain-strategic">potencjał</span> talentów w Twoim zespole
            </h1>
            
            <p className="text-xl text-white/80 leading-relaxed mb-10 max-w-2xl mx-auto">
              TalentPilot pomaga menedżerom zrozumieć unikalne talenty każdego członka zespołu, 
              budować silniejsze relacje i maksymalizować efektywność współpracy.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link to="/auth">
                <Button variant="hero" size="xl" className="w-full sm:w-auto">
                  Rozpocznij za darmo
                  <ArrowRight className="h-5 w-5" />
                </Button>
              </Link>
              <Link to="/dashboard">
                <Button variant="glass" size="xl" className="w-full sm:w-auto">
                  Zobacz demo
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Domains */}
      <section className="py-16 border-b">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-headline mb-4">4 domeny, 34 talenty</h2>
            <p className="text-body max-w-2xl mx-auto">
              Metodologia Gallupa dzieli talenty na cztery główne domeny, 
              które pomagają zrozumieć naturalne predyspozycje każdej osoby.
            </p>
          </div>
          
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {domains.map((domain) => (
              <div
                key={domain.name}
                className="group relative overflow-hidden rounded-2xl border bg-card p-6 shadow-soft transition-all hover:shadow-elevated hover:-translate-y-1"
              >
                <div className={`absolute inset-0 ${domain.color} opacity-5 group-hover:opacity-10 transition-opacity`} />
                <div className={`h-3 w-12 rounded-full ${domain.color} mb-4`} />
                <h3 className="text-title mb-2">{domain.name}</h3>
                <p className="text-3xl font-bold font-display">{domain.count}</p>
                <p className="text-sm text-muted-foreground">talentów</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-headline mb-4">Wszystko, czego potrzebujesz</h2>
            <p className="text-body max-w-2xl mx-auto">
              Kompletny zestaw narzędzi do zarządzania talentami zespołu
            </p>
          </div>
          
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {features.map((feature) => (
              <div
                key={feature.title}
                className="rounded-2xl border bg-card p-6 shadow-soft transition-all hover:shadow-elevated"
              >
                <div className="mb-4 inline-flex rounded-xl bg-primary/10 p-3 text-primary">
                  <feature.icon className="h-6 w-6" />
                </div>
                <h3 className="text-title mb-2">{feature.title}</h3>
                <p className="text-body">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-gradient-hero text-white">
        <div className="container">
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="text-headline mb-6">
              Gotowy, by odkryć talenty swojego zespołu?
            </h2>
            <p className="text-lg text-white/80 mb-8">
              Dołącz do menedżerów, którzy budują silniejsze zespoły 
              dzięki zrozumieniu unikalnych talentów każdej osoby.
            </p>
            <Link to="/auth">
              <Button variant="warm" size="xl">
                Rozpocznij za darmo
                <ArrowRight className="h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-12">
        <div className="container">
          <div className="flex flex-col items-center justify-between gap-6 md:flex-row">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-primary text-primary-foreground font-bold text-sm">
                TP
              </div>
              <span className="font-display font-semibold">TalentPilot</span>
            </div>
            <p className="text-sm text-muted-foreground">
              © 2024 TalentPilot. Wszelkie prawa zastrzeżone.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

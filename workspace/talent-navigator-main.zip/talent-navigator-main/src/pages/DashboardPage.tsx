import { AppLayout } from '@/components/AppLayout';
import { KPICard } from '@/components/KPICard';
import { DomainChart } from '@/components/DomainChart';
import { TeamMemberCard } from '@/components/TeamMemberCard';
import { mockTeamMembers, mockDomainDistribution, mockKPIs, mockDailyTips } from '@/data/mockData';
import { Users, Target, ArrowRightLeft, Sparkles, TrendingUp, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { DomainBadge } from '@/components/DomainBadge';

export default function DashboardPage() {
  const latestTip = mockDailyTips[0];

  return (
    <AppLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-headline">Panel główny</h1>
            <p className="text-body">Witaj, Anno! Oto przegląd Twojego zespołu.</p>
          </div>
          <Link to="/team">
            <Button variant="hero" size="lg">
              Zarządzaj zespołem
              <ArrowRight className="h-5 w-5" />
            </Button>
          </Link>
        </div>

        {/* KPI Grid */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <KPICard
            title="Członków zespołu"
            value={mockKPIs.teamSize}
            subtitle="aktywnych użytkowników"
            icon={<Users className="h-6 w-6" />}
            trend={{ value: 12, isPositive: true }}
          />
          <KPICard
            title="Zaimportowane talenty"
            value={mockKPIs.talentsImported}
            subtitle="profili talentowych"
            icon={<Target className="h-6 w-6" />}
          />
          <KPICard
            title="Porównań 1:1"
            value={mockKPIs.comparisonsMade}
            subtitle="w tym miesiącu"
            icon={<ArrowRightLeft className="h-6 w-6" />}
            trend={{ value: 8, isPositive: true }}
          />
          <KPICard
            title="Zaangażowanie"
            value={`${mockKPIs.avgEngagement}%`}
            subtitle="średnia aktywność"
            icon={<TrendingUp className="h-6 w-6" />}
            trend={{ value: 5, isPositive: true }}
          />
        </div>

        {/* Main content grid */}
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Domain distribution */}
          <div className="lg:col-span-1">
            <div className="rounded-2xl border bg-card p-6 shadow-soft">
              <DomainChart distribution={mockDomainDistribution} />
            </div>
          </div>

          {/* Daily tip */}
          <div className="lg:col-span-2">
            <div className="rounded-2xl border bg-gradient-to-br from-domain-strategic-light to-background p-6 shadow-soft">
              <div className="flex items-start gap-4">
                <div className="rounded-xl bg-domain-strategic/10 p-3 text-domain-strategic">
                  <Sparkles className="h-6 w-6" />
                </div>
                <div className="flex-1 space-y-3">
                  <div className="flex items-center gap-2">
                    <span className="text-label">Dzienna wskazówka</span>
                    <DomainBadge domain={latestTip.targetDomain || 'strategic'} size="sm" />
                  </div>
                  <h3 className="text-title">{latestTip.title}</h3>
                  <p className="text-body leading-relaxed">{latestTip.content}</p>
                  <Link to="/tips">
                    <Button variant="outline" size="sm">
                      Zobacz więcej wskazówek
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Team members */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-title">Twój zespół</h2>
            <Link to="/team" className="text-sm text-primary hover:underline">
              Zobacz wszystkich →
            </Link>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {mockTeamMembers.slice(0, 4).map((member) => (
              <TeamMemberCard
                key={member.id}
                member={member}
                onClick={() => {}}
              />
            ))}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}

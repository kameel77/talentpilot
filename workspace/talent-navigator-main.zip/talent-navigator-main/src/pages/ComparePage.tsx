import { useState } from 'react';
import { AppLayout } from '@/components/AppLayout';
import { TeamMemberCard } from '@/components/TeamMemberCard';
import { DomainBadge } from '@/components/DomainBadge';
import { mockTeamMembers } from '@/data/mockData';
import { getTalentById, DOMAIN_LABELS } from '@/data/gallupTalents';
import { TeamMember, GallupDomain } from '@/types/talent';
import { Button } from '@/components/ui/button';
import {
  ArrowRightLeft,
  Link as LinkIcon,
  AlertTriangle,
  Lightbulb,
  User,
  ChevronRight,
} from 'lucide-react';
import { cn } from '@/lib/utils';

export default function ComparePage() {
  const [personA, setPersonA] = useState<TeamMember | null>(null);
  const [personB, setPersonB] = useState<TeamMember | null>(null);
  const [showResults, setShowResults] = useState(false);

  const handleSelect = (member: TeamMember) => {
    if (!personA) {
      setPersonA(member);
    } else if (!personB && member.id !== personA.id) {
      setPersonB(member);
    }
  };

  const handleCompare = () => {
    if (personA && personB) {
      setShowResults(true);
    }
  };

  const handleReset = () => {
    setPersonA(null);
    setPersonB(null);
    setShowResults(false);
  };

  const availableMembers = mockTeamMembers.filter(
    (m) => m.id !== personA?.id && m.id !== personB?.id
  );

  return (
    <AppLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-headline">Porównanie 1:1</h1>
          <p className="text-body">Odkryj mosty i bariery między dwoma osobami</p>
        </div>

        {/* Selection area */}
        {!showResults && (
          <>
            <div className="flex flex-col gap-4 md:flex-row md:items-center">
              {/* Person A */}
              <div className="flex-1">
                <p className="text-label mb-2">Osoba A</p>
                {personA ? (
                  <SelectedPersonCard
                    member={personA}
                    onClear={() => setPersonA(null)}
                  />
                ) : (
                  <div className="flex h-24 items-center justify-center rounded-2xl border-2 border-dashed border-border bg-muted/30">
                    <p className="text-muted-foreground">Wybierz pierwszą osobę</p>
                  </div>
                )}
              </div>

              {/* Arrow */}
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary self-center">
                <ArrowRightLeft className="h-5 w-5" />
              </div>

              {/* Person B */}
              <div className="flex-1">
                <p className="text-label mb-2">Osoba B</p>
                {personB ? (
                  <SelectedPersonCard
                    member={personB}
                    onClear={() => setPersonB(null)}
                  />
                ) : (
                  <div className="flex h-24 items-center justify-center rounded-2xl border-2 border-dashed border-border bg-muted/30">
                    <p className="text-muted-foreground">Wybierz drugą osobę</p>
                  </div>
                )}
              </div>
            </div>

            {/* Compare button */}
            {personA && personB && (
              <div className="flex justify-center">
                <Button variant="hero" size="lg" onClick={handleCompare}>
                  Porównaj
                  <ChevronRight className="h-5 w-5" />
                </Button>
              </div>
            )}

            {/* Available members */}
            {(!personA || !personB) && (
              <div className="space-y-4">
                <h3 className="text-title">
                  {!personA ? 'Wybierz pierwszą osobę' : 'Wybierz drugą osobę'}
                </h3>
                <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                  {availableMembers.map((member) => (
                    <TeamMemberCard
                      key={member.id}
                      member={member}
                      compact
                      onClick={() => handleSelect(member)}
                    />
                  ))}
                </div>
              </div>
            )}
          </>
        )}

        {/* Results */}
        {showResults && personA && personB && (
          <ComparisonResults personA={personA} personB={personB} onReset={handleReset} />
        )}
      </div>
    </AppLayout>
  );
}

// Selected person card
interface SelectedPersonCardProps {
  member: TeamMember;
  onClear: () => void;
}

function SelectedPersonCard({ member, onClear }: SelectedPersonCardProps) {
  const topTalent = getTalentById(member.topTalents[0]);

  return (
    <div className="relative flex items-center gap-4 rounded-2xl border bg-card p-4 shadow-soft">
      <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-gradient-primary text-primary-foreground text-lg font-semibold">
        {member.firstName[0]}{member.lastName[0]}
      </div>
      <div className="flex-1 min-w-0">
        <p className="font-semibold truncate">
          {member.firstName} {member.lastName}
        </p>
        {topTalent && (
          <DomainBadge domain={topTalent.domain} size="sm" />
        )}
      </div>
      <button
        onClick={onClear}
        className="absolute -right-2 -top-2 flex h-6 w-6 items-center justify-center rounded-full bg-muted text-muted-foreground hover:bg-destructive hover:text-destructive-foreground transition-colors"
      >
        ×
      </button>
    </div>
  );
}

// Comparison results
interface ComparisonResultsProps {
  personA: TeamMember;
  personB: TeamMember;
  onReset: () => void;
}

function ComparisonResults({ personA, personB, onReset }: ComparisonResultsProps) {
  // Generate comparison data
  const talentsA = new Set(personA.topTalents);
  const talentsB = new Set(personB.topTalents);
  
  // Shared talents (bridges)
  const sharedTalents = [...talentsA].filter((t) => talentsB.has(t));
  
  // Complementary domains
  const domainsA = new Set(personA.topTalents.map((t) => getTalentById(t)?.domain));
  const domainsB = new Set(personB.topTalents.map((t) => getTalentById(t)?.domain));
  
  const bridges = [
    sharedTalents.length > 0 
      ? `Wspólne talenty: ${sharedTalents.map((t) => getTalentById(t)?.namePl).join(', ')}`
      : null,
    domainsA.has('relationship') && domainsB.has('executing')
      ? `${personA.firstName} może budować relacje, podczas gdy ${personB.firstName} realizuje zadania`
      : null,
    domainsA.has('strategic') && domainsB.has('influencing')
      ? `${personA.firstName} może planować strategie, a ${personB.firstName} wpływać na ich wdrożenie`
      : null,
    `Oboje cenią efektywną komunikację w zespole`,
    `Mogą się uzupełniać w podejściu do rozwiązywania problemów`,
  ].filter(Boolean);

  const barriers = [
    personA.triggers.some((t) => t.toLowerCase().includes('tempo')) && personB.topTalents.includes('deliberative')
      ? `${personA.firstName} może się frustrować powolnym tempem ${personB.firstName}`
      : null,
    personA.topTalents.includes('command') && personB.topTalents.includes('harmony')
      ? `Bezpośredni styl ${personA.firstName} może kolidować z unikaniem konfliktów przez ${personB.firstName}`
      : null,
    `Różne style komunikacji mogą wymagać świadomego dostosowania`,
    `Różne priorytety mogą prowadzić do nieporozumień bez jasnych ustaleń`,
  ].filter(Boolean);

  const tips = [
    `Ustalcie wspólny język komunikacji przed ważnymi projektami`,
    `Wykorzystujcie mocne strony obu osób - delegujcie zadania zgodnie z talentami`,
    `Regularnie sprawdzajcie wzajemne oczekiwania i potrzeby`,
    `Doceniajcie wkład drugiej osoby, nawet jeśli różni się od waszego stylu`,
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header with both people */}
      <div className="flex flex-col items-center gap-4 md:flex-row md:justify-center">
        <div className="flex items-center gap-3">
          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-primary text-primary-foreground text-xl font-bold">
            {personA.firstName[0]}{personA.lastName[0]}
          </div>
          <div>
            <p className="font-semibold">{personA.firstName}</p>
            <p className="text-sm text-muted-foreground">{personA.lastName}</p>
          </div>
        </div>
        
        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-primary">
          <ArrowRightLeft className="h-5 w-5" />
        </div>
        
        <div className="flex items-center gap-3">
          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-warm text-white text-xl font-bold">
            {personB.firstName[0]}{personB.lastName[0]}
          </div>
          <div>
            <p className="font-semibold">{personB.firstName}</p>
            <p className="text-sm text-muted-foreground">{personB.lastName}</p>
          </div>
        </div>
      </div>

      {/* Results grid */}
      <div className="grid gap-6 md:grid-cols-2">
        {/* Bridges */}
        <div className="rounded-2xl border bg-gradient-to-br from-success/5 to-transparent p-6 shadow-soft">
          <h3 className="text-title mb-4 flex items-center gap-2">
            <LinkIcon className="h-5 w-5 text-success" />
            Mosty
          </h3>
          <p className="text-sm text-muted-foreground mb-4">
            Obszary, które łączą te dwie osoby i ułatwiają współpracę
          </p>
          <ul className="space-y-3">
            {bridges.slice(0, 4).map((bridge, i) => (
              <li key={i} className="flex items-start gap-3 text-sm">
                <span className="mt-1 flex h-5 w-5 items-center justify-center rounded-full bg-success/20 text-success text-xs">
                  ✓
                </span>
                {bridge}
              </li>
            ))}
          </ul>
        </div>

        {/* Barriers */}
        <div className="rounded-2xl border bg-gradient-to-br from-warning/5 to-transparent p-6 shadow-soft">
          <h3 className="text-title mb-4 flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-warning" />
            Bariery
          </h3>
          <p className="text-sm text-muted-foreground mb-4">
            Potencjalne punkty tarcia wymagające uwagi
          </p>
          <ul className="space-y-3">
            {barriers.slice(0, 4).map((barrier, i) => (
              <li key={i} className="flex items-start gap-3 text-sm">
                <span className="mt-1 flex h-5 w-5 items-center justify-center rounded-full bg-warning/20 text-warning text-xs">
                  !
                </span>
                {barrier}
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Tips */}
      <div className="rounded-2xl border bg-gradient-to-br from-primary/5 to-transparent p-6 shadow-soft">
        <h3 className="text-title mb-4 flex items-center gap-2">
          <Lightbulb className="h-5 w-5 text-primary" />
          Wskazówki do współpracy
        </h3>
        <div className="grid gap-3 sm:grid-cols-2">
          {tips.map((tip, i) => (
            <div
              key={i}
              className="flex items-start gap-3 rounded-xl bg-background/50 p-4 text-sm"
            >
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary text-xs font-medium">
                {i + 1}
              </span>
              {tip}
            </div>
          ))}
        </div>
      </div>

      {/* Reset button */}
      <div className="flex justify-center">
        <Button variant="outline" onClick={onReset}>
          Nowe porównanie
        </Button>
      </div>
    </div>
  );
}

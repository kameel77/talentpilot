import { useState } from 'react';
import { AppLayout } from '@/components/AppLayout';
import { DomainBadge } from '@/components/DomainBadge';
import { mockDailyTips } from '@/data/mockData';
import { DailyTip, GallupDomain } from '@/types/talent';
import { Button } from '@/components/ui/button';
import {
  Sparkles,
  ThumbsUp,
  ThumbsDown,
  RefreshCw,
  MessageSquare,
  Users,
  TrendingUp,
  Award,
  ChevronRight,
  ChevronLeft,
} from 'lucide-react';
import { cn } from '@/lib/utils';

const categoryIcons = {
  communication: MessageSquare,
  collaboration: Users,
  development: TrendingUp,
  leadership: Award,
};

const categoryLabels = {
  communication: 'Komunikacja',
  collaboration: 'Współpraca',
  development: 'Rozwój',
  leadership: 'Przywództwo',
};

export default function TipsPage() {
  const [currentTipIndex, setCurrentTipIndex] = useState(0);
  const [tips, setTips] = useState<DailyTip[]>(mockDailyTips);
  
  const currentTip = tips[currentTipIndex];
  const CategoryIcon = categoryIcons[currentTip.category];

  const handleFeedback = (isHelpful: boolean) => {
    setTips((prev) =>
      prev.map((tip, i) =>
        i === currentTipIndex ? { ...tip, isHelpful } : tip
      )
    );
  };

  const goToNext = () => {
    if (currentTipIndex < tips.length - 1) {
      setCurrentTipIndex(currentTipIndex + 1);
    }
  };

  const goToPrev = () => {
    if (currentTipIndex > 0) {
      setCurrentTipIndex(currentTipIndex - 1);
    }
  };

  return (
    <AppLayout>
      <div className="mx-auto max-w-2xl space-y-6">
        {/* Header */}
        <div className="text-center">
          <h1 className="text-headline">Dzienna wskazówka</h1>
          <p className="text-body">
            Spersonalizowane porady na podstawie talentów Twojego zespołu
          </p>
        </div>

        {/* Main tip card */}
        <div className="relative overflow-hidden rounded-3xl border bg-card shadow-elevated">
          {/* Gradient background */}
          <div
            className={cn(
              'absolute inset-0 opacity-10',
              currentTip.targetDomain === 'executing' && 'bg-gradient-to-br from-domain-executing to-transparent',
              currentTip.targetDomain === 'influencing' && 'bg-gradient-to-br from-domain-influencing to-transparent',
              currentTip.targetDomain === 'relationship' && 'bg-gradient-to-br from-domain-relationship to-transparent',
              currentTip.targetDomain === 'strategic' && 'bg-gradient-to-br from-domain-strategic to-transparent'
            )}
          />
          
          <div className="relative p-6 md:p-8">
            {/* Category and domain */}
            <div className="mb-6 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="rounded-lg bg-primary/10 p-2 text-primary">
                  <CategoryIcon className="h-5 w-5" />
                </div>
                <span className="text-sm font-medium">
                  {categoryLabels[currentTip.category]}
                </span>
              </div>
              {currentTip.targetDomain && (
                <DomainBadge domain={currentTip.targetDomain} size="sm" />
              )}
            </div>

            {/* Tip icon */}
            <div className="mb-6 flex justify-center">
              <div className="flex h-20 w-20 items-center justify-center rounded-2xl bg-gradient-primary text-primary-foreground shadow-glow">
                <Sparkles className="h-10 w-10" />
              </div>
            </div>

            {/* Title */}
            <h2 className="text-headline text-center mb-4">
              {currentTip.title}
            </h2>

            {/* Content */}
            <p className="text-body-lg text-center leading-relaxed">
              {currentTip.content}
            </p>

            {/* Feedback */}
            <div className="mt-8 flex flex-col items-center gap-4">
              <p className="text-sm text-muted-foreground">Czy ta wskazówka była pomocna?</p>
              <div className="flex items-center gap-3">
                <Button
                  variant={currentTip.isHelpful === true ? 'default' : 'outline'}
                  size="lg"
                  onClick={() => handleFeedback(true)}
                  className={cn(
                    currentTip.isHelpful === true && 'bg-success hover:bg-success/90'
                  )}
                >
                  <ThumbsUp className="h-5 w-5" />
                  Tak
                </Button>
                <Button
                  variant={currentTip.isHelpful === false ? 'default' : 'outline'}
                  size="lg"
                  onClick={() => handleFeedback(false)}
                  className={cn(
                    currentTip.isHelpful === false && 'bg-destructive hover:bg-destructive/90'
                  )}
                >
                  <ThumbsDown className="h-5 w-5" />
                  Nie
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-between">
          <Button
            variant="ghost"
            onClick={goToPrev}
            disabled={currentTipIndex === 0}
          >
            <ChevronLeft className="h-5 w-5" />
            Poprzednia
          </Button>
          
          <div className="flex items-center gap-2">
            {tips.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrentTipIndex(i)}
                className={cn(
                  'h-2 w-2 rounded-full transition-all',
                  i === currentTipIndex
                    ? 'w-6 bg-primary'
                    : 'bg-muted hover:bg-muted-foreground/30'
                )}
              />
            ))}
          </div>
          
          <Button
            variant="ghost"
            onClick={goToNext}
            disabled={currentTipIndex === tips.length - 1}
          >
            Następna
            <ChevronRight className="h-5 w-5" />
          </Button>
        </div>

        {/* Tips history */}
        <div className="space-y-3">
          <h3 className="text-title">Wcześniejsze wskazówki</h3>
          <div className="space-y-2">
            {tips.map((tip, i) => {
              if (i === currentTipIndex) return null;
              return (
                <button
                  key={tip.id}
                  onClick={() => setCurrentTipIndex(i)}
                  className="w-full rounded-xl border bg-card p-4 text-left transition-all hover:shadow-soft hover:border-primary/30"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{tip.title}</p>
                      <p className="text-sm text-muted-foreground truncate mt-1">
                        {tip.content.slice(0, 80)}...
                      </p>
                    </div>
                    {tip.isHelpful !== null && (
                      <div
                        className={cn(
                          'rounded-full p-1.5',
                          tip.isHelpful
                            ? 'bg-success/10 text-success'
                            : 'bg-destructive/10 text-destructive'
                        )}
                      >
                        {tip.isHelpful ? (
                          <ThumbsUp className="h-4 w-4" />
                        ) : (
                          <ThumbsDown className="h-4 w-4" />
                        )}
                      </div>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}

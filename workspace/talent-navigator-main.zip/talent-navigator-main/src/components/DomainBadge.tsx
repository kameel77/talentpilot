import { GallupDomain } from '@/types/talent';
import { DOMAIN_LABELS } from '@/data/gallupTalents';
import { cn } from '@/lib/utils';

interface DomainBadgeProps {
  domain: GallupDomain;
  size?: 'sm' | 'md' | 'lg';
  showLabel?: boolean;
  className?: string;
}

const domainStyles: Record<GallupDomain, string> = {
  executing: 'bg-domain-executing-light text-domain-executing border-domain-executing/30',
  influencing: 'bg-domain-influencing-light text-domain-influencing border-domain-influencing/30',
  relationship: 'bg-domain-relationship-light text-domain-relationship border-domain-relationship/30',
  strategic: 'bg-domain-strategic-light text-domain-strategic border-domain-strategic/30',
};

const sizeStyles = {
  sm: 'px-2 py-0.5 text-xs',
  md: 'px-3 py-1 text-sm',
  lg: 'px-4 py-1.5 text-base',
};

export function DomainBadge({ domain, size = 'md', showLabel = true, className }: DomainBadgeProps) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-full border font-medium transition-all',
        domainStyles[domain],
        sizeStyles[size],
        className
      )}
    >
      <span
        className={cn(
          'rounded-full',
          size === 'sm' ? 'h-1.5 w-1.5' : size === 'md' ? 'h-2 w-2' : 'h-2.5 w-2.5',
          domain === 'executing' && 'bg-domain-executing',
          domain === 'influencing' && 'bg-domain-influencing',
          domain === 'relationship' && 'bg-domain-relationship',
          domain === 'strategic' && 'bg-domain-strategic'
        )}
      />
      {showLabel && DOMAIN_LABELS[domain].pl}
    </span>
  );
}

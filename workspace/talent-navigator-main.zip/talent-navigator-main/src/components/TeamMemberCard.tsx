import { TeamMember } from '@/types/talent';
import { getTalentById } from '@/data/gallupTalents';
import { DomainBadge } from './DomainBadge';
import { cn } from '@/lib/utils';
import { User } from 'lucide-react';

interface TeamMemberCardProps {
  member: TeamMember;
  onClick?: () => void;
  isSelected?: boolean;
  compact?: boolean;
  className?: string;
}

export function TeamMemberCard({ 
  member, 
  onClick, 
  isSelected, 
  compact = false,
  className 
}: TeamMemberCardProps) {
  const topTalent = member.topTalents[0] ? getTalentById(member.topTalents[0]) : null;

  if (compact) {
    return (
      <button
        onClick={onClick}
        className={cn(
          'flex items-center gap-3 rounded-xl border bg-card p-3 text-left transition-all',
          'hover:shadow-soft hover:border-primary/30',
          isSelected && 'border-primary ring-2 ring-primary/20',
          className
        )}
      >
        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-primary">
          <User className="h-5 w-5" />
        </div>
        <div className="min-w-0 flex-1">
          <p className="truncate font-medium">
            {member.firstName} {member.lastName}
          </p>
          {topTalent && (
            <DomainBadge domain={topTalent.domain} size="sm" showLabel={false} />
          )}
        </div>
      </button>
    );
  }

  return (
    <button
      onClick={onClick}
      className={cn(
        'group relative flex flex-col rounded-2xl border bg-card p-5 text-left transition-all duration-300',
        'hover:shadow-elevated hover:-translate-y-1 hover:border-primary/30',
        isSelected && 'border-primary ring-2 ring-primary/20',
        className
      )}
    >
      {/* Avatar */}
      <div className="mb-4 flex items-center gap-4">
        <div className="relative">
          <div className="flex h-14 w-14 items-center justify-center rounded-full bg-gradient-primary text-primary-foreground text-lg font-semibold">
            {member.firstName[0]}{member.lastName[0]}
          </div>
          {member.role === 'manager' && (
            <div className="absolute -bottom-1 -right-1 h-5 w-5 rounded-full bg-warning flex items-center justify-center text-[10px]">
              ⭐
            </div>
          )}
        </div>
        <div className="min-w-0 flex-1">
          <h3 className="truncate font-semibold text-lg">
            {member.firstName} {member.lastName}
          </h3>
          <p className="text-sm text-muted-foreground capitalize">
            {member.role === 'manager' ? 'Menedżer' : member.role === 'admin' ? 'Administrator' : 'Członek zespołu'}
          </p>
        </div>
      </div>

      {/* Top talents preview */}
      <div className="flex flex-wrap gap-2">
        {member.topTalents.slice(0, 3).map((talentId) => {
          const talent = getTalentById(talentId);
          if (!talent) return null;
          return (
            <DomainBadge 
              key={talentId} 
              domain={talent.domain} 
              size="sm"
            />
          );
        })}
        {member.topTalents.length > 3 && (
          <span className="text-xs text-muted-foreground self-center">
            +{member.topTalents.length - 3} więcej
          </span>
        )}
      </div>

      {/* Hover indicator */}
      <div className="absolute inset-x-0 bottom-0 h-1 rounded-b-2xl bg-gradient-primary opacity-0 transition-opacity group-hover:opacity-100" />
    </button>
  );
}

import { DomainDistribution } from '@/types/talent';
import { DOMAIN_LABELS } from '@/data/gallupTalents';
import { cn } from '@/lib/utils';

interface DomainChartProps {
  distribution: DomainDistribution;
  className?: string;
}

const domainBarColors = {
  executing: 'bg-domain-executing',
  influencing: 'bg-domain-influencing',
  relationship: 'bg-domain-relationship',
  strategic: 'bg-domain-strategic',
};

export function DomainChart({ distribution, className }: DomainChartProps) {
  const total = Object.values(distribution).reduce((a, b) => a + b, 0);
  const domains = Object.entries(distribution) as [keyof DomainDistribution, number][];

  return (
    <div className={cn('space-y-4', className)}>
      <h3 className="text-title">Rozkład domenowy zespołu</h3>
      <div className="space-y-3">
        {domains.map(([domain, value]) => {
          const percentage = Math.round((value / total) * 100);
          return (
            <div key={domain} className="space-y-1.5">
              <div className="flex items-center justify-between text-sm">
                <span className="font-medium">{DOMAIN_LABELS[domain].pl}</span>
                <span className="text-muted-foreground">{percentage}%</span>
              </div>
              <div className="h-3 w-full overflow-hidden rounded-full bg-muted">
                <div
                  className={cn(
                    'h-full rounded-full transition-all duration-700 ease-out',
                    domainBarColors[domain]
                  )}
                  style={{ width: `${percentage}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>
      
      {/* Mini pie representation */}
      <div className="mt-6 flex items-center justify-center gap-2">
        {domains.map(([domain, value]) => {
          const percentage = Math.round((value / total) * 100);
          return (
            <div
              key={domain}
              className={cn(
                'h-12 rounded-lg transition-all hover:scale-105',
                domainBarColors[domain]
              )}
              style={{ width: `${percentage}%`, minWidth: '2rem' }}
              title={`${DOMAIN_LABELS[domain].pl}: ${percentage}%`}
            />
          );
        })}
      </div>
    </div>
  );
}
